package AllApiDtoClasses;

public class ApiGraphDataPointDTO {
    public long semesterCode;
    public long totalCoursesTaken;
}
