package AllApiDtoClasses;

public class ApiCourseDTO {
    public long courseId;
    public String catalogNumber;
}
