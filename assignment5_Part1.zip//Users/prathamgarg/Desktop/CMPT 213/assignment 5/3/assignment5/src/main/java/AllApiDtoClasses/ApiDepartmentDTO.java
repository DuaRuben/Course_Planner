package AllApiDtoClasses;

public class ApiDepartmentDTO {
    public long deptId;
    public String name;
}
